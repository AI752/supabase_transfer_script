import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.7.1";
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type"
};
serve(async (req)=>{
  // Handle CORS preflight request
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: corsHeaders,
      status: 204
    });
  }
  try {
    // Create a Supabase client with the Auth context of the logged in user
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_ANON_KEY") ?? "", {
      global: {
        headers: {
          Authorization: req.headers.get("Authorization")
        }
      }
    });
    // Get authenticated user
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({
        error: "Nicht authentifiziert"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 401
      });
    }
    // Parse the request body
    const { chatId, userIds } = await req.json();
    if (!chatId || !userIds || !Array.isArray(userIds)) {
      return new Response(JSON.stringify({
        error: "Ungültige Anfrage"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 400
      });
    }
    // Verify user is the owner of the chat
    const { data: chatData, error: chatError } = await supabase.from('chats').select('*').eq('id', chatId).single();
    if (chatError || !chatData || chatData.user_id !== user.id) {
      return new Response(JSON.stringify({
        error: "Sie sind nicht Besitzer dieses Chats"
      }), {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json"
        },
        status: 403
      });
    }
    // Update chat participants
    const updatedParticipants = [
      ...chatData.participants || []
    ];
    for (const userId of userIds){
      if (!updatedParticipants.includes(userId)) {
        updatedParticipants.push(userId);
      }
    }
    const { error: updateError } = await supabase.from('chats').update({
      participants: updatedParticipants,
      is_private: false
    }).eq('id', chatId);
    if (updateError) {
      throw updateError;
    }
    // For each new participant, add the chat to their default folder
    for (const userId of userIds){
      // Find user's default folder
      const { data: folderData } = await supabase.from('folders').select('id').eq('user_id', userId).is('parent_id', null).order('created_at', {
        ascending: true
      }).limit(1);
      const defaultFolderId = folderData && folderData.length > 0 ? folderData[0].id : null;
      if (defaultFolderId) {
        // Add to user_chat_folders
        await supabase.from('user_chat_folders').upsert({
          user_id: userId,
          chat_id: chatId,
          folder_id: defaultFolderId
        }).on_conflict([
          'user_id',
          'chat_id'
        ]).ignore(); // If entry already exists, ignore the insert
      }
    }
    return new Response(JSON.stringify({
      success: true
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 200
    });
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({
      error: "Interner Serverfehler"
    }), {
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json"
      },
      status: 500
    });
  }
});
